// config.js - DO NOT COMMIT THIS FILE
window.API_AUTH = {
    'Authorization': 'token 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'
  };