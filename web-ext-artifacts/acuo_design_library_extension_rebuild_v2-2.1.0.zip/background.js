// Listen for alt text toggle messages
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'showAltText' || message.action === 'hideAltText') {
        // Send the message to all tabs
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { action: message.action });
            });
        });
    }
});

// Initialize alt text state when extension loads
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get('showAltText', function(data) {
      if (typeof data.showAltText === 'undefined') {
          chrome.storage.local.set({ showAltText: false });
      }
  });
});